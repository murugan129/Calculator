package calculatorTests;

import java.io.File;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC001_CalculatorTest {
	static WebDriver driver;
	@BeforeTest
	public void setup(){
		//Setup the Chrome driver
		System.setProperty("webdriver.chrome.driver","C:\\Drivers\\chromedriver.exe");	
		System.setProperty("org.uncommons.reportng.escape-output", "false");
		driver = new ChromeDriver();
	}
	
	@BeforeMethod
	public void beforeEachMethod(){
		driver.get("https://duffmanns.github.io/calc-test/calculator/app/index.html");
	    driver.manage().window().maximize();
	}
	public static void takeScreenshot() throws Exception {
		String timeStamp;
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()); 
		FileUtils.copyFile(scrFile, new File("./src/test/resources/Screenshots/"+timeStamp+".png"));
	}
	
  @Test
  public void Calculate() throws Exception {
		
	  	Reporter.log("Logging into online Calculator", true);
	    
	  	//User entering the following equation
	    String strFormula = "(10-8) × 3";
	    
	    strFormula = strFormula.replaceAll(" ", "");
	    
	    char[] arrFormula = strFormula.toCharArray();
	    
	    for (int l=0;l<arrFormula.length;l++)
	    {
	    	if(Character.toString(arrFormula[l]).equals("(") || (Character.toString(arrFormula[l]).equals(")")))
	    	{
	    		System.out.println(arrFormula[l]);
	    	}else
	    	{	
	    		//User click on the respective number in the formula in the UI calculator screen
	    		driver.findElement(By.xpath("//input[@value = '"+arrFormula[l] + "']")).click();
	    		Reporter.log("User clicked  '" + arrFormula[l]  + " 'button", true);
	    		Thread.sleep(400);
	    		//Take screen output at each step in the formula 
	    		takeScreenshot();
		    }	    
	    }
	    driver.findElement(By.xpath("//input[@value = '=']")).click();
	    Reporter.log("User clicked '=' button", true);
	    Thread.sleep(300);
	  //Take screen output at each step in the formula
	    takeScreenshot();
	    WebElement strOutput = driver.findElement(By.xpath("//*[@id=\'display\']/div"));
	    Reporter.log("Given formula : " + strFormula + " Result output is: " + strOutput.getText(), true);
  }
  @AfterTest
  public void endOfTest(){
  //Close all the Webdriver sessions
  driver.quit();
  }
}